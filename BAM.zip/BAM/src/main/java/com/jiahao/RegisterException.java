package com.jiahao;

public class RegisterException extends BusinessException {
    public RegisterException(String message) {
        super(message);
    }
}