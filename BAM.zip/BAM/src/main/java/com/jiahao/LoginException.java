package com.jiahao;

public class LoginException extends BusinessException {
    public LoginException(String message) {
        super(message);
    }
}
