package com.jiahao;

public class LoanException extends BusinessException {
    public LoanException(String message) {
        super(message);
    }
}
