package com.jiahao;

// BalanceNotEnoughException
public class BalanceNotEnoughException extends BusinessException {
    public BalanceNotEnoughException(String message) {
        super(message);
    }
}
